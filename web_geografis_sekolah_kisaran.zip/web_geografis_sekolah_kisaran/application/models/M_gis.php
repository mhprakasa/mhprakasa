<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_gis extends CI_Model {


	//tambah data sekolah
	public function tambah($data)
	{
		$this->db->insert('tbl_sekolah', $data);
	}

	//mengambil semua data ke tabel sekolah dan pemetaan
	public function datasekolah()
	{
		$this->db->select('*');
		$this->db->from('tbl_sekolah');
		$query=$this->db->get();
		return $query->result();
	}

	//hapus data sekolah
	public function delete($data)
	{
		$this->db->where('id_sekolah', $data['id_sekolah']);
		$this->db->delete('tbl_sekolah');
	}

	//detail sekolah
	public function detail($id_sekolah)
	{
		$this->db->select('*');
		$this->db->from('tbl_sekolah');
		$this->db->where('id_sekolah', $id_sekolah);
		$query=$this->db->get();
		return $query->row();
	}

	//merudab data sekolah
	public function update($data)
	{
		$this->db->where('id_sekolah', $data['id_sekolah']);
		$this->db->update('tbl_sekolah',$data);
	}

}

/* End of file M_gis.php */
/* Location: ./application/models/M_gis.php */