<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gis extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library(array('googlemaps'));
		$this->load->model('m_gis');
	}

	public function index()
	{
		$this->load->library('googlemaps');
		$config['center'] = '2.984473, 99.628812';
		$config['zoom'] = '15';
		$this->googlemaps->initialize($config);

		$sekolah=$this->m_gis->datasekolah();
		foreach ($sekolah as $key => $value) {
			$marker = array();
			$marker['animation'] = 'DROP';
			$marker['position'] = "$value->latitude, $value->longitude";
			$marker['infowindow_content'] = '<div class="media" style="width:300px;">';
			$marker['infowindow_content'] .= '<div class="media-left">';
			$marker['infowindow_content'] .= '</div>';
			$marker['infowindow_content'] .= '<div class="media-body">';
			$marker['infowindow_content'] .= '<h5 class="media-heading">'.$value->nama_sekolah.'</h5>';
			$marker['infowindow_content'] .= '<a>'.$value->alamat.'</a><br>';
			$marker['infowindow_content'] .= '<a>'.$value->no_telpon.'</a><br>';
			$marker['infowindow_content'] .= '<a>'.$value->deskripsi.'</a><br>';
			$marker['infowindow_content'] .= '</div>';
			$marker['infowindow_content'] .= '</div>';
			$marker['icon'] = base_url('assets/icon/sekolah.png');

			$this->googlemaps->add_marker($marker);
		}
		$this->googlemaps->initialize($config);


		$data['map'] = $this->googlemaps->create_map();
		$this->load->view('v_home', $data, FALSE);
	}

	public function about(){
		$data['map'] = $this->googlemaps->create_map();
		$this->load->view('v_about', $data, FALSE);
	}

}

/* End of file Gis.php */
/* Location: ./application/controllers/Gis.php */