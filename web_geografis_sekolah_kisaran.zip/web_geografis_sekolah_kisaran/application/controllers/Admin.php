<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->simple_login->cek_login();
		$this->load->library(array('googlemaps'));
		$this->load->model('m_gis');
	}

	public function index()
	{
		$this->load->library('googlemaps');
		$config['center'] = '2.984473, 99.628812';
		$config['zoom'] = '15';
		$this->googlemaps->initialize($config);

		$sekolah=$this->m_gis->datasekolah();
		foreach ($sekolah as $key => $value) {
			$marker = array();
			$marker['animation'] = 'DROP';
			$marker['position'] = "$value->latitude, $value->longitude";
			$marker['infowindow_content'] = '<div class="media" style="width:300px;">';
			$marker['infowindow_content'] .= '<div class="media-left">';
			$marker['infowindow_content'] .= '</div>';
			$marker['infowindow_content'] .= '<div class="media-body">';
			$marker['infowindow_content'] .= '<h5 class="media-heading">'.$value->nama_sekolah.'</h5>';
			$marker['infowindow_content'] .= '<a>'.$value->alamat.'</a><br>';
			$marker['infowindow_content'] .= '<a>'.$value->no_telpon.'</a><br>';
			$marker['infowindow_content'] .= '<a>'.$value->deskripsi.'</a><br>';
			$marker['infowindow_content'] .= '</div>';
			$marker['infowindow_content'] .= '</div>';
			$marker['icon'] = base_url('assets/icon/sekolah.png');

			$this->googlemaps->add_marker($marker);
		}
		$this->googlemaps->initialize($config);


		$data['map'] = $this->googlemaps->create_map();
		$this->load->view('v_admin', $data, FALSE);
	}

	public function inputsekolah()
	{	
		//menampilkan peta lokasi
		$this->load->library('googlemaps');
		$config['center'] = '2.984473, 99.628812';
		$config['zoom'] = '15';
		$this->googlemaps->initialize($config);

		$marker['position'] = '2.984473, 99.628812';
		$marker['draggable'] = true;
		$marker['ondragend'] = 'setMapToForm(event.latLng.lat(),event.latLng.lng());';
		$this->googlemaps->add_marker($marker);

		//validasi input
		$valid=$this->form_validation;
		$valid->set_rules('nama_sekolah','Nama Sekolah','required',array('required' =>'%s Harus Diisi'));

		if($valid->run()==FALSE)
		{
			$data['map'] = $this->googlemaps->create_map();
			$this->load->view('v_inputsekolah', $data, FALSE);
		}else{
			$i=$this->input;
			$data = array('nama_sekolah' => $i->post('nama_sekolah') ,
						'alamat' => $i->post('alamat'),
						'no_telpon' => $i->post('no_telpon'),
						'latitude' => $i->post('latitude'),
						'longitude' => $i->post('longitude'),
						'deskripsi' => $i->post('deskripsi')
						 );
			$this->m_gis->tambah($data);
			$this->session->set_flashdata('sukses', 'Data Sekolah Berhasil Di Tambahkan');
			redirect(base_url('admin/inputsekolah'),'refresh');

		}
	}

	public function datasekolah()
	{	
		$sekolah=$this->m_gis->datasekolah();
		$map= $this->googlemaps->create_map();
		$data = array(
						'map' 		=>$map,
					  	'sekolah'	=>$sekolah
					);
		$this->load->view('v_datasekolah', $data, FALSE);
	}

	//delete data sekolah
	public function delete($id_sekolah)
	{
		$data = array('id_sekolah' => $id_sekolah);
		$this->m_gis->delete($data);
		$this->session->set_flashdata('sukses','Data Berhasil Dihapus');
		redirect(base_url('admin/datasekolah'),'refresh');
	}

	//update data sekolah
	public function update($id_sekolah)
	{	
		//menampilkan peta lokasi
		$this->load->library('googlemaps');
		$config['center'] = '2.984473, 99.628812';
		$config['zoom'] = '15';
		$this->googlemaps->initialize($config);
		$marker['position'] = '2.984473, 99.628812';
		$marker['draggable'] = true;
		$marker['ondragend'] = 'setMapToForm(event.latLng.lat(),event.latLng.lng());';
		$this->googlemaps->add_marker($marker);

		//validasi input
		$sekolah=$this->m_gis->detail($id_sekolah);
		$valid=$this->form_validation;
		$valid->set_rules('nama_sekolah','Nama Sekolah','required',array('required' =>'%s Harus Diisi'));

		if($valid->run()==FALSE)
		{
			$map= $this->googlemaps->create_map();
				$data = array(
						'map' 		=>$map,
					  	'sekolah'	=>$sekolah
					);
			$this->load->view('v_updatesekolah', $data, FALSE);
		}else{
			$i=$this->input;
			$data = array(
						'id_sekolah' => $id_sekolah,
						'nama_sekolah' => $i->post('nama_sekolah') ,
						'alamat' => $i->post('alamat'),
						'no_telpon' => $i->post('no_telpon'),
						'latitude' => $i->post('latitude'),
						'longitude' => $i->post('longitude'),
						'deskripsi' => $i->post('deskripsi')
						 );
			$this->m_gis->update($data);
			$this->session->set_flashdata('sukses', 'Data Sekolah Berhasil Di Update');
			redirect(base_url('admin/datasekolah'),'refresh');

		}
	}
}

/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */