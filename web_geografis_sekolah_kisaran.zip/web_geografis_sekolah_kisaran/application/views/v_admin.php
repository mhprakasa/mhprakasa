<?php include("header_admin.php"); ?>



<div class="container">    
  <div class="row">
    <div class="col-sm-12">
      <div class="panel panel-primary">
        <div class="panel-heading">Pemetaan Lokasi Sekolah</div>
        <div class="panel-body">
          <?php echo $map['html']; ?>


        </div>
        <div class="panel-footer"></div>
      </div>
    </div>
  </div>
</div>




<?php include("footer.php"); ?>